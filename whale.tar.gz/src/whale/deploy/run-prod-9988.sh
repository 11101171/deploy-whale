#!/bin/bash
# ./run-9988.sh start
./run.sh $1 9988 'prod'
