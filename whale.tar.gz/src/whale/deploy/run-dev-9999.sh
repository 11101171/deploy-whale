#!/bin/bash
# ./run-9999.sh start
./run.sh $1 9999 'dev'
